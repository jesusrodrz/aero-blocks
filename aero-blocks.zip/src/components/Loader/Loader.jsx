import './style.scss';

const Loader = props => {
  return (
    <div className="Loader-watch">
      <i className="i-clock"></i>
    </div>
  );
};

export default Loader;
