// import Parallax from 'parallax-js';
// console.log('work?');
// const sectionParallax = [...document.querySelectorAll('.section-parallax')];
// console.log(sectionParallax);
// const parallaxInstances =
//   sectionParallax.length > 0 &&
//   sectionParallax.map(section => {
//     const parallaxInstance = new Parallax(section, {
//       // relativeInput: true,
//       selector: '.section-parallax__img'
//     });

//     return parallaxInstance;
//   });
// console.log(parallaxInstances);
